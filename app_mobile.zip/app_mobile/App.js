
import React, { useEffect, useRef, useState } from 'react';
import {TouchableOpacity, ImageBackground, Text, View, StyleSheet, Button,Animated, TextInput, KeyboardAvoidingView, Platform} from 'react-native';
import Constants from 'expo-constants';




export default function App() {

  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  const send = () => {

  } 

  const input1Ref = useRef (null)
  
  const input2Ref = useRef (null)

  const input3Ref = useRef (null)

  return (




    <View style={styles.container}>
    <ImageBackground
    source = {require('./assets/back.png')} 
    style = {styles.imageBackground}>


    <KeyboardAvoidingView
  style={styles.container}
  behavior={Platform.OS === 'ios' ? 'padding' : null }
   enabled={Platform.OS === 'android'}
>


    <TextInput
      style ={styles.email}
      placeholder="E-mail"
      value={email}
      onChangeText={setEmail}  
      placeholderTextColor="#FFFAFA" 
      returnKeyType ="next"
      onSubmmitEditing = {() => input2Ref.current.focus()}
      ref={input1Ref}
    />

   <View>
    <TextInput

      style ={styles.senha} 
      placeholder="senha"
      value={senha}
      onChangeText={setSenha}  
      placeholderTextColor="#FFFAFA" 
      returnKeyType = "done"
      ref={input2Ref}
    />

    </View>
     <View>
    <TextInput

      style ={styles.senha} 
      placeholder="confirme a senha"
      value={senha}
      onChangeText={setSenha}  
      placeholderTextColor="#FFFAFA" 
    />

    </View>

    <View style = {styles.entrar}>
    <Button style = {styles.butonTEste}
    title = "ENTRAR" 
    />
    </View>

    </KeyboardAvoidingView> 




 



    </ImageBackground>

      
    </View>
  );
}

const styles = StyleSheet.create({



  imageBackground: {
    flex: 1,
    resizeMode: "cover",
    height: '100%',
    width: '100%',
    justifyContent: "center",
    alignItems: "center"
  },
  container : {
    flex: 1,
    alignItems: 'center',  
    justifyContent: 'center',
  },
  senha: {
    borderWidth:1 ,
    width: 300 ,
     borderColor: '#1C1C1C', 
    borderRadius: 10,
    padding: 10,
    margin: 10,  
    backgroundColor: 'transparent',
  },
    email: {
    borderWidth:1 ,
    width: 300 ,
    borderColor: '#1C1C1C', 
    borderRadius: 10,
    padding: 10,
    margin: 10,
    marginTop: 40,       
    backgroundColor: 'transparent',
  },
  entrar: {
    margin: 10,
    width: 300,
    borderWidth: 2,
    borderColor: '#6A5ACD',
    borderRadius:15,   
    backgroundColor: '#6A5ACD', 
    color: '#F5FFFA', 
  },




 



});
