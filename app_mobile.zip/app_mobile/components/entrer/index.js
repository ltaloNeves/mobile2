
import React, { useEffect, useRef, useState } from 'react';
import {TouchableOpacity, ImageBackground, Text, View, StyleSheet, Button,Animated} from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';



export default function App() {

  const [IsPressed, setIsPressed] = useState(false);

  const handlePress = () => {  
    setIsPressed(true);
    setTimeout(() => {
      setIsPressed(false);

    }, 100);

  };
 

  const onPressButton = () => {
    Linking.openURL('https://www.undbclassroom.undb.edu.br/'); 


  }
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(-20)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(opacity,{
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(translateY,{
        toValue: 0,
        duration:100,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);


  return (




    <View style={styles.container}>
    <ImageBackground
    source = {require('./assets/back.png')} 
    style = {styles.imageBackground}>

      <Animated.Text style={[styles.headerDois, {opacity,transform: [{translateY}] }]}> 
        <Text style = { styles.header}>AMAMENTAÇÃO</Text>

        
      </Animated.Text>

        <View style = {styles.prince }> 
        <Text style = {styles.h2}>O aplicativo para te guiar</Text>      
        </View>

      <View style={styles.login}> 
        <Button title = 'LOGIN' 
        style = {styles.loginButton}
        onPress = {onPressButton}
        color = '#FFFAFA'
      />


      </View>

      <View style = {styles.cadastro}>    
        <Button title = 'CADASTRAR'
        onPress = {onPressButton} 
        color = '#FFFAFA'
        />
      </View>

      <View 
      style = {styles.continuar}> 
      <Button
      style = {styles.continuardois}
      title = 'continuar sem login'
      color= '#FFFAFA'       />
      </View>




    </ImageBackground>



      
    </View>
  );
}

const styles = StyleSheet.create({


  imageBackground: {
    flex: 1,
    resizeMode: "cover",
    height: '100%',
    width: '100%',
    justifyContent: "center",
    alignItems: "center"
  },
  container : {
    flex: 1,
    alignItems: 'center', 
  },
     
  prince: {
    marginTop: 20,
    alignItems: 'center',  
  },
  headerDois:{
    marginTop: 100,
    fontSize: 40,
    marginBottom: 20,


  },
  header:{
    fontSize: 40,
    marginBottom: 20, 
    borderWidth: 2, 
  },
  h2 : {
    fontSize: 20,
    marginBottom: 100,

  },
  login: {
    
    margin: 10,
    width: 300, 
    borderWidth: 2,
    borderColor: '#6A5ACD',
    borderRadius:10, 
    backgroundColor: '#6A5ACD', 
    color: '#F5FFFA',


  }, 
  cadastro: {
    margin: 10,
    width: 300,
    borderWidth: 2,
    borderColor: '#6A5ACD',
    borderRadius:10, 
    backgroundColor: '#6A5ACD', 
    color: '#F5FFFA',

  },
  continuar: {  
    marginTop: 200,
    width: 200,
    borderRadius:20, 
    backgroundColor: 'transparent',
    color: '#1C1C1C',
    borderColor: 'transparent',



  },




});
