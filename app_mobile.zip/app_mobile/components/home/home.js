
import React, { useEffect, useRef } from 'react';
import {ImageBackground, Text, View, StyleSheet, Button,Animated} from 'react-native';
import Constants from 'expo-constants';

export default function Home() {
  return(

    
    
  )
  
}