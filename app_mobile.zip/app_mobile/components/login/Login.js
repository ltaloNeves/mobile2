
import React, { useEffect, useRef, useState } from 'react';
import {TouchableOpacity, ImageBackground, Text, View, StyleSheet, Button,Animated, TextInput, KeyboardAvoidingView} from 'react-native';
import Constants from 'expo-constants';




export default function App() {

  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  const send = () => {

  } 
  const [isItemVisible, setIsItemVisible] = useState(true);
  return (




    <View style={styles.container}>
    <ImageBackground
    source = {require('./assets/back.png')} 
    style = {styles.imageBackground}>

    <View style = {styles.dois}>
    {isItemVisible && (
    <Text style = {styles.header}>
      Bem vindo de Volta
      </Text>
      
    )}
  
    </View>

    <KeyboardAvoidingView
      style={styles.containerDois}
      behavior="position" 
      keyboardVerticalOffset={1} 
    >

     <View >
    <TextInput
      onFocus={() => setIsItemVisible(false)}
      onBlur ={() => setIsItemVisible(true)}
      style ={styles.email}
      placeholder="E-mail"
      value={email}
      onChangeText={setEmail}  
      placeholderTextColor="#FFFAFA" 
    />

    </View>


    <View>
    <TextInput
      onFocus={() => setIsItemVisible(false)}
      onBlur ={() => setIsItemVisible(true)}
      style ={styles.senha} 
      placeholder="senha"
      value={email}
      onChangeText={setEmail}  
      placeholderTextColor="#FFFAFA" 
    />

    </View>

    <View style = {styles.entrar}>
    <Button style = {styles.butonTEste}
    title = "ENTRAR" 
    />
    </View>


    {isItemVisible && ( 

    <View style = {styles.enter}> 
    <TouchableOpacity style = {styles.button}> 
    <Text style = {styles.itens}> 
    Cadastrar agora 
    </Text>
    </TouchableOpacity>
    </View>

    )}





    </KeyboardAvoidingView>



    </ImageBackground>

      
    </View>
  );
}

const styles = StyleSheet.create({



  imageBackground: {
    flex: 1,
    resizeMode: "cover",
    height: '100%',
    width: '100%',
    justifyContent: "center",
    alignItems: "center"
  },
  container : {
    flex: 1,
    alignItems: 'center',  
    justifyContent: 'center',
  },

  entrar: {
    margin: 10,
    width: 300,
    borderWidth: 2,
    borderColor: '#6A5ACD',
    borderRadius:15,   
    backgroundColor: '#6A5ACD', 
    color: '#F5FFFA',
  },
  senha: {
    borderWidth:1 ,
    width: 300 ,
     borderColor: '#1C1C1C', 
    borderRadius: 10,
    padding: 10,
    margin: 10,  
    backgroundColor: 'transparent',
  },
    email: {
    borderWidth:1 ,
    width: 300 ,
    borderColor: '#1C1C1C', 
    borderRadius: 10,
    padding: 10,
    margin: 10,
    marginTop: 40,       
    backgroundColor: 'transparent',
  },
     
  header : {
    fontSize: 40,
    margin: 10, 
    marginTop: 200,         
  },
  dois: {
    marginTop:200,
    fontSize: 40,
    marginBottom: 10,
    
  },
  containerDois: {
    marginTop: 50,
    marginBottom: 400,
  },
  enter: {
    borderColor: 'transparent', 
    backgroundColor: 'transparent',
  },

  button : {
    backgroundColor: 'transparent',
    marginLeft: 10,
    marginTop: 50, 
  },
  itens: {
    texAlign: 'center', 
  }



 



});
